package apcsweek14;

import java.util.ArrayList;

public class APCSWeek14 {

    public static void addSomeApples(int apples) {
        apples += 2;
        System.out.println("Inside method: " + apples);
    }

    public static int addSomeApplesForReal(int apples) {
        apples += 2;
        return apples;
    }

    public static void addMarvelHero(ArrayList<String> list, String newHero) {

        list.add(newHero);

    }

    public static void reviewMethod() {
        // ArrayList things
        ArrayList<String> list = new ArrayList<String>();
        int apples = 5;
        System.out.println("apples start: " + apples);
        addSomeApples(apples);
        System.out.println("apples end: " + apples);

        apples = addSomeApplesForReal(apples);
        System.out.println("apples for real: " + apples);

        list.add("Thanos");
        list.add("Thor");
        list.add("Captain America");
        System.out.println("list before add: " + list);
        addMarvelHero(list, "Ironman");
        System.out.println("list after add: " + list);
        // Nice code

        if (5 == 5) {
            System.out.println("It's 5!");
            if (5 == 10) {
                System.out.println("Blah");
            } else {
                System.out.println("sojdaopds");
            }
        }
    }

    public static void main(String[] args) {
//        reviewMethod();

//        // Classes
        Person kevin = new Person("Kevin");
        System.out.println(kevin.toString());
//        Person melody = new Person("Melody");
//        melody.printPerson();
//        Person idiot = new Person("Stefan");
//        idiot.printPerson();
//        idiot.changeName("Stefanek");
//        idiot.printPerson();

//        Cat newCat = new Cat("Qian", "Yellow", 80);
//        newCat.meow();

//        kevin.setAge(18);
//        
//        if (kevin.isAdult()) {
//            System.out.println("Kevin can drink alcohol in Canada!");
//        }

            // Printing nice decimals

            double decimal = (double)2 / 3;
            System.out.println(String.format("%.2f", decimal));
            
         System.out.println("Kevin can drink alcohol? " + kevin.canDrinkAlcohol());
         
         kevin.age(40);
         
         System.out.println(kevin.toString());
    }

}
