/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apcsweek14;

/**
 *
 * @author thinkpad
 */
public class Cat {
   private int age;
   private String name;
   private String colour;
   private int weight;
   
   public Cat(String name, String colour,int weight){
       this.name = name;
       this.age = 0;
       this.colour = colour;
       this.weight = weight;
       
   }
   public void meow(){
       System.out.println("meow");
   }
   
   

}
