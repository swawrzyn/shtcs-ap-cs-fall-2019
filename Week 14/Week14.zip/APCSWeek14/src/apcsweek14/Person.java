package apcsweek14;

public class Person {
    private String name;
    private int age;
    private int cancerRisk;

    public Person(String constName) {
        this.name = constName;
        this.age = 0;
        this.cancerRisk = 0;
    }
    
    public void changeName(String name) {
        this.name = name;
    }
    
    public void setAge(int age) {
        this.age = age;
    }
    
    public void age(int years) {
        int risk = (years / 4);
        this.cancerRisk += risk;
        this.age += years;
    }
    
    public boolean isAdult() {
        if (this.age >= 18) {
            return true;
        } else {
            return false;
        }
    }
    
    public boolean canDrinkAlcohol() {
        return this.isAdult();
    }

    public String toString() {
        return "Name: " + this.name + ", Age: " + this.age + ", Cancer Risk: " + this.cancerRisk + "%";
    }
}
