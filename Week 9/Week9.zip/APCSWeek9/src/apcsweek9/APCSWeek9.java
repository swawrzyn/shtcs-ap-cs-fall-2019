package apcsweek9;

/**
 * AP CS A - Week 9 - Methods and ArrayList
 * 
 */
import java.util.ArrayList;
import java.util.Scanner;
public class APCSWeek9 {
    
    public static void shoutName(String name) {
        System.out.println(name + "!!!");
    }
    
    public static void reviewMethod() {
        // All review material for the previous weeks
        // if statement
        int apples = 1;
        if (apples > 1) {
            System.out.println("You have many apples!");
        } else if (apples < 1) {
            System.out.println("You have no apples!");
        } else {
            System.out.println("You have an apple!");
        }
        // while loop and iteration
        int i = 0;
        while (true) {
            if (i % 2 == 0) {
                System.out.println(i);
            } else if (i > 100) {
                break;
            }
            i++;
        }
        
        // basics of methods
        
        shoutName("Kevin");
    }
    
    public static void addStudentDumb(int students) {
        System.out.println("Inside method students: " + students);
        students += 1;
        System.out.println("Inside method students: " + students);
    }
    
    public static int addStudentSmart(int students) {
        students += 1;
        return students;
    }
    
    public static boolean evenNumber(int number) {
        return number % 2 == 0;
    }
    
    public static void classList() {
        Scanner reader = new Scanner(System.in);
        System.out.println("welcome to the classlist program");
        ArrayList<String> student = new ArrayList<String>();
        while(true){
            System.out.println("");
            System.out.println("1. list all students ");
            System.out.println("2. add student");
            System.out.println("4. quit");
            System.out.print("what do you want to do: ");
            String input = reader.nextLine();
        if(input.equals("4")){
            break;
        }else if(input.equals("2")){
            System.out.print("Enter student name: ");
            String input2 = reader.nextLine();
            student.add(input2 );
            System.out.println(input2 + " added");
                  
        }else if(input.equals("1")){
            System.out.println(student);
        }
    }
    }
    
    public static void main(String[] args) {
//         reviewMethod();
//        int students = 5;
//        System.out.println("Number of students: " + students);
//        addStudentDumb(students);
//        System.out.println("Number outside of students: " + students);
//        System.out.println(addStudentSmart(students));

//        String name = "Qian";
//        String sentence = "Qian is a terrible programmer";
//        
//        System.out.println(sentence.indexOf("terrible"));
//          ArrayList<String> fruits = new ArrayList<String>();
//          
//          fruits.add("Peach");
//          fruits.add("Watermelon");
//          fruits.add("Orange");
//          fruits.add("Apple");
//          
//          System.out.println(fruits);
//          
//          fruits.remove("Peach");
//          System.out.println(fruits);
//          
//          System.out.println(fruits.get(2));
//          
//          System.out.println(fruits.contains("Cherry"));

            classList();
        
    }
    
}
