
package apcsweek10;

/**
 *
 * In class work for Week 10 of AP CS
 */
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class APCSWeek10 {
    
    public static void addBanana(int bananas) {
        bananas++;
        System.out.println("Num of bananas inside: " + bananas);
    }
    
    public static int addBananaForReal(int bananas) {
        bananas++;
        return bananas;
    }
    
    public static void reviewMethod() {
        // methods and variables
        int bananas = 5;
        addBanana(bananas);
        System.out.println("Num of bananas outside: " + bananas);
        // return
        int newBananas = 5;
        newBananas = addBananaForReal(newBananas);
        System.out.println("New number of bananas: " + newBananas);
        // Strings
        System.out.println("");
        System.out.println("-----STRINGS------");
        System.out.println("");
        
        String country = "China";
        String sentence = "Mainland China is the best!";
        System.out.println("country word length: " + country.length());
        System.out.println(sentence.indexOf(country));
        System.out.println(sentence.substring(5, 10));
        System.out.println(country.equals("America"));
        // Objects
        Scanner reader = new Scanner(System.in);
        String normally = "Hello!";
        String properly = new String("Hello!");
        // ArrayList
        ArrayList<String> classes = new ArrayList<String>();
        
        classes.add("Math");
        classes.add("English");
        
        classes.remove("English");
        // OR
        // classes.remove(1);
        
        System.out.println(classes);
        System.out.println(classes.get(0));
    }
    
    public static void firstWay(ArrayList<String> names) {
        System.out.println(names.get(0));
        System.out.println(names.get(1));
        System.out.println(names.get(2));
        System.out.println(names.get(3));
        System.out.println(names.get(4));
   }
    
    public static void secondWay(ArrayList<String> names){
        int i = 0;
        while (true) {
            System.out.println(names.get(i));
            i++;
            if (names.size() - 1 < i) {
                break;
            }
        }
    }
    
    public static void thirdWay(ArrayList<String> names) {
        
        for (String name : names) {
            System.out.println(name);
        }
        
    }
    
    public static void collectionsMethod(ArrayList<String> list) {
        System.out.println("");
        System.out.println("------ORDERED------");
        System.out.println("");
        
        Collections.sort(list);
        
        for (String name : list){
            System.out.println(name);
        }
        
        System.out.println("");
        System.out.println("------SHUFFLED------");
        System.out.println("");
        
        Collections.shuffle(list);
        
        for (String name : list){
            System.out.println(name);
        }
        
        System.out.println("");
        System.out.println("------REVERSE------");
        System.out.println("");
        
        Collections.reverse(list);
        
        for (String name : list){
            System.out.println(name);
        }
    }
    
    public static void kevinPractice1() {
        ArrayList<String> names = new ArrayList<String>();
        names.add("Fei");
        names.add("Chris");
        names.add("Stefan");
        names.add("Judy");
        names.add("Rachel");
        Collections.sort(names);
        Collections.reverse(names);
        for (String name : names){
            System.out.println(name);
        
        
        
        }
        
    }
    
    public static void classList() {
        Scanner reader = new Scanner(System.in);
        System.out.println("welcome to the classlist program");
        ArrayList<String> student = new ArrayList<String>();
        while(true){
            System.out.println("");
            System.out.println("1. list all students ");
            System.out.println("2. add student");
            System.out.println("3. remove student");
            System.out.println("4. quit");
            System.out.print("what do you want to do: ");
            String input = reader.nextLine();
        if(input.equals("4")){
            break;
        }else if(input.equals("2")){
            System.out.print("Enter student name: ");
            String input2 = reader.nextLine();
            student.add(input2);
            Collections.sort(student);
            System.out.println(input2 + " added");
                  
        }else if(input.equals("1")){
            if(student.isEmpty()){
                System.out.println("No student found");    
            }
            for (String name : student){
                System.out.println(name);
            }
        }else if(input.equals("3")) {
            for (String name : student){
                System.out.println(name);
                
            }
            System.out.print("Enter student name: ");
                String input2 = reader.nextLine();
                student.remove(input2);
        }
    }
    }

    public static void main(String[] args) {
//        reviewMethod();
//        ArrayList<String> names = new ArrayList<String>();
//        names.add("Kevin");
//        names.add("Stefan");
//        names.add("Melody");
//        names.add("Sherry");
//        names.add("Qian");
//          firstWay(names);
//          secondWay(names);
//          thirdWay(names);
//            collectionsMethod(names);
//          kevinPractice1();
           classList();
         
    }
    
}
